import asyncio
import json

from fastapi import APIRouter, Request
from fastapi.responses import FileResponse, JSONResponse
from starlette.responses import RedirectResponse

import core
from core import templates
from routers.videos.watch import _EDU_PARAMS_CACHE

HARDCODED_PASSWORD = "aiueo"
AUTH_COOKIE_NAME = "choco_auth"
AUTH_COOKIE_VALUE = "choco_session_ok"
WELCOME_COOKIE_NAME = "choco_welcome_seen"
LANGUAGE_COOKIE_NAME = "alueo_language"
CURRENT_VERSION = "1.42"

router = APIRouter()



@router.get("/")
async def index_page(request: Request):
    self_url = str(request.base_url).rstrip("/")
    if not core._keepalive_self_url:
        core._keepalive_self_url = self_url
    asyncio.create_task(core._ping_keepalive(self_url))
    return templates.TemplateResponse(request, "index.html", {"active": "home", "language": request.cookies.get(LANGUAGE_COOKIE_NAME, "ja")})


@router.get("/trending")
async def trending_page(request: Request):
    return templates.TemplateResponse(request, "trending.html", {"active": "trending"})


@router.get("/dl")
async def dl_page(request: Request):
    return templates.TemplateResponse(request, "dl.html", {"active": "dl"})


@router.get("/watch")
async def watch_page(request: Request):
    return templates.TemplateResponse(request, "watch.html")


@router.get("/shorts/{video_id}")
async def shorts_page(request: Request, video_id: str):
    cached = _EDU_PARAMS_CACHE.get("data")
    edu_params_json = json.dumps(cached["json"] if cached else [])
    return templates.TemplateResponse(request, "shorts.html", {"edu_params_json": edu_params_json})


@router.get("/shorts")
async def shorts_index_page(request: Request):
    return templates.TemplateResponse(request, "shorts.html", {"edu_params_json": "[]", "active": "shorts"})


@router.get("/search")
async def search_page(request: Request):
    return templates.TemplateResponse(request, "search.html")


@router.get("/channel")
async def channel_page(request: Request):
    return templates.TemplateResponse(request, "channel.html")


@router.get("/playlist")
async def playlist_page(request: Request):
    return templates.TemplateResponse(request, "playlist.html")


@router.get("/hashtag")
async def hashtag_page(request: Request):
    return templates.TemplateResponse(request, "hashtag.html")


@router.get("/mix")
async def mix_page(request: Request):
    return templates.TemplateResponse(request, "mix.html")


@router.get("/library")
async def library_page(request: Request):
    return templates.TemplateResponse(request, "library.html", {"active": "library"})


@router.get("/settings")
async def settings_page(request: Request):
    return templates.TemplateResponse(request, "settings.html", {"active": "settings"})


@router.get("/links")
async def links_page(request: Request):
    return templates.TemplateResponse(request, "links.html")


@router.get("/about")
async def about_page(request: Request):
    is_first_visit = not request.cookies.get(WELCOME_COOKIE_NAME)
    resp = templates.TemplateResponse(
        request, "about.html",
        {"active": "about", "current_version": CURRENT_VERSION, "is_first_visit": is_first_visit},
    )
    resp.set_cookie(WELCOME_COOKIE_NAME, "1", httponly=True, samesite="lax", max_age=86400 * 365)
    return resp


@router.get("/contact")
async def contact_page(request: Request):
    return templates.TemplateResponse(request, "contact.html", {"active": "contact"})


@router.get("/login")
async def login_page(request: Request):
    return templates.TemplateResponse(request, "login.html")


@router.get("/forgot")
async def forgot_page(request: Request):
    return templates.TemplateResponse(request, "forgot.html")


@router.post("/api/quiz-login")
async def api_quiz_login(request: Request):
    try:
        data = await request.json()
    except Exception:
        return JSONResponse({"ok": False, "message": "リクエストが無効です"}, status_code=400)

    score = data.get("score", 0)
    total = data.get("total", 5)

    if score < 3:
        return JSONResponse({"ok": False, "message": "正解数が足りません"}, status_code=401)

    seen_welcome = request.cookies.get(WELCOME_COOKIE_NAME)
    redirect_url = "/language"
    response = JSONResponse({"ok": True, "redirect": redirect_url})
    response.set_cookie(
        AUTH_COOKIE_NAME,
        AUTH_COOKIE_VALUE,
        httponly=True,
        samesite="lax",
        max_age=86400 * 30,
    )
    return response


@router.post("/api/login")
async def api_login(request: Request):
    try:
        data = await request.json()
    except Exception:
        return JSONResponse({"ok": False, "message": "リクエストが無効です"}, status_code=400)

    password = (data.get("password") or "").strip()

    if password != HARDCODED_PASSWORD:
        return JSONResponse({"ok": False, "message": "パスワードが正しくありません"}, status_code=401)

    seen_welcome = request.cookies.get(WELCOME_COOKIE_NAME)
    redirect_url = "/language"
    response = JSONResponse({"ok": True, "redirect": redirect_url})
    response.set_cookie(
        AUTH_COOKIE_NAME,
        AUTH_COOKIE_VALUE,
        httponly=True,
        samesite="lax",
        max_age=86400 * 30,
    )
    return response


@router.get("/logout")
async def logout():
    response = RedirectResponse(url="/login")
    response.delete_cookie(AUTH_COOKIE_NAME)
    return response




@router.get("/language")
async def language_page(request: Request):
    return templates.TemplateResponse(request, "language.html", {"language": request.cookies.get(LANGUAGE_COOKIE_NAME, "ja")})


@router.post("/api/language")
async def api_language(request: Request):
    try:
        data = await request.json()
    except Exception:
        data = {}
    lang = str(data.get("language") or "ja").lower()
    allowed = {"ja", "en", "zh", "ko", "es", "fr", "de", "pt", "it", "ru"}
    if lang not in allowed:
        return JSONResponse({"ok": False, "message": "Unsupported language"}, status_code=400)
    response = JSONResponse({"ok": True, "language": lang, "redirect": "/"})
    response.set_cookie(LANGUAGE_COOKIE_NAME, lang, httponly=False, samesite="lax", max_age=86400*365)
    return response
