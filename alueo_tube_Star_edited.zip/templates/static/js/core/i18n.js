(() => {
  const dict={
    ja:{home:'ホーム',trending:'トレンド',library:'ライブラリ',shorts:'Shorts',subscriptions:'登録チャンネル',settings:'設定',about:'概要',search:'動画を検索...',recommend:'おすすめ',history:'履歴',download:'ダウンロード'},
    en:{home:'Home',trending:'Trending',library:'Library',shorts:'Shorts',subscriptions:'Subscriptions',settings:'Settings',about:'About',search:'Search videos...',recommend:'Recommended',history:'History',download:'Download'},
    zh:{home:'首页',trending:'热门',library:'媒体库',shorts:'Shorts',subscriptions:'订阅',settings:'设置',about:'关于',search:'搜索视频...',recommend:'推荐',history:'历史记录',download:'下载'},
    ko:{home:'홈',trending:'트렌드',library:'라이브러리',shorts:'Shorts',subscriptions:'구독 채널',settings:'설정',about:'정보',search:'동영상 검색...',recommend:'추천',history:'기록',download:'다운로드'},
    es:{home:'Inicio',trending:'Tendencias',library:'Biblioteca',shorts:'Shorts',subscriptions:'Suscripciones',settings:'Ajustes',about:'Acerca de',search:'Buscar vídeos...',recommend:'Recomendados',history:'Historial',download:'Descargar'},
    fr:{home:'Accueil',trending:'Tendances',library:'Bibliothèque',shorts:'Shorts',subscriptions:'Abonnements',settings:'Paramètres',about:'À propos',search:'Rechercher des vidéos...',recommend:'Recommandés',history:'Historique',download:'Télécharger'},
    de:{home:'Startseite',trending:'Trends',library:'Mediathek',shorts:'Shorts',subscriptions:'Abos',settings:'Einstellungen',about:'Über',search:'Videos suchen...',recommend:'Empfohlen',history:'Verlauf',download:'Herunterladen'},
    pt:{home:'Início',trending:'Tendências',library:'Biblioteca',shorts:'Shorts',subscriptions:'Inscrições',settings:'Configurações',about:'Sobre',search:'Pesquisar vídeos...',recommend:'Recomendados',history:'Histórico',download:'Baixar'},
    it:{home:'Home',trending:'Tendenze',library:'Raccolta',shorts:'Shorts',subscriptions:'Iscrizioni',settings:'Impostazioni',about:'Info',search:'Cerca video...',recommend:'Consigliati',history:'Cronologia',download:'Scarica'},
    ru:{home:'Главная',trending:'В тренде',library:'Библиотека',shorts:'Shorts',subscriptions:'Подписки',settings:'Настройки',about:'О сервисе',search:'Поиск видео...',recommend:'Рекомендации',history:'История',download:'Скачать'}
  };
  const lang=localStorage.getItem('alueo-language')||'ja'; const d=dict[lang]||dict.ja; document.documentElement.lang=lang;
  const map={home:'ホーム',trending:'トレンド',library:'ライブラリ',shorts:'Shorts',subscriptions:'登録チャンネル',settings:'設定',about:'概要',download:'ダウンロード'};
  document.querySelectorAll('.sidebar-nav-link span').forEach(el=>{const key=Object.keys(map).find(k=>map[k]===el.textContent.trim()); if(key&&d[key])el.textContent=d[key]});
  document.querySelectorAll('.search-input,.home-search-input').forEach(el=>el.placeholder=d.search);
  document.querySelectorAll('.home-tab').forEach(el=>{if(el.dataset.tab==='recommend')el.lastChild.textContent=' '+d.recommend});
})();